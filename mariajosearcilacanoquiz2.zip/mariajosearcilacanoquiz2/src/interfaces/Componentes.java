package interfaces;

import bean.*;

public interface Componentes {

	public int getCodigo();
	
}
