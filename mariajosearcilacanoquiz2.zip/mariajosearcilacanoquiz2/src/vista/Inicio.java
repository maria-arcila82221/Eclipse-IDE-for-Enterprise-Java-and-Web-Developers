package vista;

import java.io.IOException;

public class Inicio {

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		
		Menu.MenuPrincipal();

	}

}
